@echo off
title QWSTUR HWID INSPECTOR
cls
python main.py
if %errorlevel% neq 0 (
    echo [!] Ошибка запуска. Проверь наличие Python.
    pause
)
