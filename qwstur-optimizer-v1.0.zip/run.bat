@echo off
title QWSTUR OPTIMIZER PRO
cls
python main.py
if %errorlevel% neq 0 (
    echo.
    echo [!] Ошибка запуска. Проверь наличие Python.
    pause
)
