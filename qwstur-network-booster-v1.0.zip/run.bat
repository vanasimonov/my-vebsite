@echo off
title QWSTUR NETWORK BOOSTER
cls
python main.py
if %errorlevel% neq 0 (
    echo [!] Ошибка запуска. Проверь наличие Python.
    pause
)
